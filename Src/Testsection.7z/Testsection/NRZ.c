#include "ErrorCodes.h"
#include "MasterDefine.h"
#include "App_Misc.h"
#include "Helperfunction.h"

void nrz_i(uint8_t *array, uint32_t arrayBitCount, uint8_t preliminarySign){
  uint8_t signTurn = preliminarySign;
  uint8_t signTurnMem = 0x01;
  for (uint32_t i = 0; i < arrayBitCount; i++){
    if (checkBitInPosition(array, i) == 0x00){
      signTurnMem ^= 0x01;
    }
    if (signTurn == 0x00){
      flipBitInPosition(array, i);
    }
    signTurn = signTurnMem;
  }
}