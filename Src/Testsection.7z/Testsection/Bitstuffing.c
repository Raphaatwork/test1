#include "ErrorCodes.h"
#include "MasterDefine.h"
#include "App_Misc.h"
#include "Helperfunction.h"


uint8_t bitstuffing(uint8_t *array, uint32_t lengthBitsUsed, uint8_t *targetArray, uint32_t *lengthTargetBits){
  uint8_t countOfConsequtiveOnes = 0;
  uint32_t targetPosition = 0;
  // For every bit do
  for (uint32_t i = 0; i < lengthBitsUsed; i++){
    // Abfang von �berlauf
    if (targetPosition == *lengthTargetBits){
      return 0x01;
    }
    // Is 0 or 1?
    if (checkBitInPosition(array, i) == 0xFF){
      // Is 1
      
      // Count up 1-count
      countOfConsequtiveOnes++;
      // Is 1-count 5?
      if (countOfConsequtiveOnes == 5){
        // Is 5
        
        // Set bit
        setBitInPosition(targetArray, targetPosition++);
        // Plug in the filling 0
        unsetBitInPosition(targetArray, targetPosition++);
        // Reset the 1-count
        countOfConsequtiveOnes = 0;
      }else{
        // Is smaller
        
        // Set bit and count up target position
        setBitInPosition(targetArray, targetPosition++);
      }
    }else{
      // Is 0
      
      // Unset that bit and count up target position
      unsetBitInPosition(targetArray, targetPosition++);
      // Reset the 1-count
      countOfConsequtiveOnes = 0;
    }
  }
  *lengthTargetBits = targetPosition;
  return 0x00;
}