#include "ErrorCodes.h"
#include "MasterDefine.h"
#include "App_Misc.h"

#define GET_FULL_BYTES (position >> 3)
#define GET_POSITION_IN_BYTE (7 - (position & 0x00000007))

void setBitInPosition(uint8_t *array, uint32_t position){
  array[GET_FULL_BYTES] |= (1 << GET_POSITION_IN_BYTE);
}
                           
void unsetBitInPosition(uint8_t *array, uint32_t position){
  array[GET_FULL_BYTES] &= (~(1 << GET_POSITION_IN_BYTE));
}

uint8_t checkBitInPosition(uint8_t *array, uint32_t position){
  if ((array[GET_FULL_BYTES] & (1 << GET_POSITION_IN_BYTE)) > 0){
    return 0xFF;
  }else{
    return 0x00;
  }
}

void flipBitInPosition(uint8_t *array, uint32_t position){
  if (checkBitInPosition(array, position) == 0x00){
    setBitInPosition(array, position);
  }else{
    unsetBitInPosition(array, position);
  }
}