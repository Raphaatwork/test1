#include "ErrorCodes.h"
#include "MasterDefine.h"
#include "App_Misc.h"
#include "Helperfunction.h"

uint32_t concatBitfields(uint8_t *arrayTarget, uint32_t arrayTargetLengthBits, uint8_t *arrayFront, uint8_t arrayFrontLengthBits, uint8_t *arrayBack, uint8_t arrayBackLengthBits){
  if (arrayTargetLengthBits < arrayFrontLengthBits + arrayBackLengthBits){
    return 0;
  }  
  arrayTargetLengthBits = 0;
  for (uint32_t i = 0; i < arrayFrontLengthBits; i++){
    if (checkBitInPosition(arrayFront, i) > 0){
      setBitInPosition(arrayTarget, i);
    }else{
      unsetBitInPosition(arrayTarget, i);
    }
    arrayTargetLengthBits++;
  }
  for (uint32_t i = 0; i < arrayBackLengthBits; i++){
    if (checkBitInPosition(arrayBack, i) > 0){
      setBitInPosition(arrayTarget, i + arrayFrontLengthBits);
    }else{
      unsetBitInPosition(arrayTarget, i + arrayFrontLengthBits);
    }
    arrayTargetLengthBits++;
  }
  return arrayTargetLengthBits;
}