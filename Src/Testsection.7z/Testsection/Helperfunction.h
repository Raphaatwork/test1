void setBitInPosition(uint8_t *array, uint32_t position);
                           
void unsetBitInPosition(uint8_t *array, uint32_t position);

uint8_t checkBitInPosition(uint8_t *array, uint32_t position);

void flipBitInPosition(uint8_t *array, uint32_t position);
